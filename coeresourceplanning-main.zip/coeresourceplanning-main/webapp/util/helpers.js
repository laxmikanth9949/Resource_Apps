sap.ui.define([
    "sap/coe/capacity/reuselib/utils/baseclasses/Helpers"
], function(HelpersBaseClass) {
    "use strict";

    var HelperClass = HelpersBaseClass.extend("sap.coe.rpa.util.Helpers", {});

    return new HelperClass();
});
