sap.ui.define([
	"sap/com/servicerequest/servicerequest/test/unit/controller/MainView.controller"
], function () {
	"use strict";
});