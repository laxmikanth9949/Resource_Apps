var a = "hello";
