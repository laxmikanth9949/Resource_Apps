sap.ui.define([
    "sap/coe/capacity/analysis/util/i18n",
    "sap/coe/capacity/analysis/util/PopoverHelper",
    "sap/coe/capacity/analysis/util/VizFrameHelper"
], function(i18nCapacity, PopoverHelper, VizFrameHelper) {
    "use strict";

    return {
        sFragmentId: "StaffedDemand",
        oVizProperties: {
            title: {
                visible: true,
                text: i18nCapacity.getText("FRAGMENT_STAFFED_DEMAND_CHART_TITLE")
            },
            plotArea: {
                mode: "percentage",
                dataLabel: {
                    type: "percentage",
                    visible: true
                },
                dataPointStyle: {
                    "rules": [{
                        "dataContext": {
                            "OpenDays": "*"
                        },
                        "properties": {
                            "color": "#5cbae6"
                        },
                        "displayName": i18nCapacity.getText("FRAGMENT_STAFFED_DEMAND_CHART_MEASURE_OPEN_DAYS")
                    }, {
                        "dataContext": {
                            "NonDays": "*"
                        },
                        "properties": {
                            "color": "#fac364"
                        },
                        "displayName": i18nCapacity.getText("FRAGMENT_STAFFED_DEMAND_CHART_MEASURE_NON_PRODUCTIVE_DAYS")
                    }, {
                        "dataContext": {
                            "ProDays": "*"
                        },
                        "properties": {
                            "color": "#b6d957"
                        },
                        "displayName": i18nCapacity.getText("FRAGMENT_STAFFED_DEMAND_CHART_MEASURE_PRODUCTIVE_DAYS")
                    }]
                }
            },
            valueAxis: {
                title: {
                    visible: false
                }
            },
            interaction: {
                selectability: {
                    plotLassoSelection: false,
                    legendSelection: false
                }
            }
        },

        /**
         * Initialises the fragment for staffedDetails and models, etc.
         *
         * @public
         * @param {sap.ui.core.mvc.Controller} oMainController - the controller of the main view
         * @return {void}
         */
        onInit: function(oMainController) {
            this.oMainController = oMainController;
            this.oMainView = oMainController.getView();

            this.oChartModel = new sap.ui.model.json.JSONModel([{}]);
            this._initVizFrame();
        },

        /**
         * Called when the StaffedDemand tab is loaded and sets the chart model
         *
         * @public
         * @return {void}
         */
        onLoadTab: function() {
            this.oVizFrame.setModel(this.oChartModel, "StaffedDemandChart");
        },

        /**
         * Retrieves a controller from the fragment based on their id
         *
         * @public
         * @param {String} sControl - the id of the control to be returned
         * @return {Object} - returns the retrieved object (if found)
         */
        byId: function(sControl) {
            return this.oMainView.byId(this.sFragmentId + "--" + sControl);
        },

        /**
         * Sets the data returned from the Capacity service to a model and binds it to the view
         *
         * @public
         * @param {Object} response - the data returned from the server for capacity information
         * @return {void}
         */
        onResponseCapacity: function(response) {
            var oCapacityData = response,
                oModel;

            if (oCapacityData) {
                oCapacityData.ProductivityPrecentage = response.TeamProdDays / response.MemberDays * 100;
                oCapacityData.ServiceOrders = response.NewSODays + response.OldSODays;
            } else {
                oCapacityData = {};
            }

            oModel = new sap.ui.model.json.JSONModel(oCapacityData);
            this.oMainView.setModel(oModel, "StaffedDemandTiles");
        },

        /**
         * Sets the data returned from the SubUnit service to a model
         *
         * @public
         * @param {Object} response - the data returned from the server for SubUnit information
         * @return {void}
         */
        onResponseSubUnit: function(response) {
            this.oChartModel = new sap.ui.model.json.JSONModel(response);
            this.oVizFrame.setModel(this.oChartModel, "StaffedDemandChart");
        },

        /**
         * Initialises the chart with its properties and feedto be used
         *
         * @private
         * @return {void}
         */
        _initVizFrame: function() {
            var oPopOver = this._createChartPopover();

            this.oVizFrame = VizFrameHelper.createVizFrame(this, oPopOver);
            this.oVizFrame.setVizProperties(this.oVizProperties);

            this._addFeeds();
        },

        /**
          * `Creates the popover displayed when user clicks on a team
          *
          * @public
          * @return {Object} - oParentContext._popover - the newly created popover
         */
        _createChartPopover: function() {
            var oParentContext = this;

            oParentContext._popover = new sap.viz.ui5.controls.Popover({
                customDataControl: function(data) {
                    var sHTMLContent = "",
                        aSelectedItems = oParentContext.oVizFrame.vizSelection();

                    if (aSelectedItems.length === 0) {
                        setTimeout(function() {
                            oParentContext._popover.close();
                        }, 400);
                        return;
                    }

                    aSelectedItems = PopoverHelper.combineBarValues(aSelectedItems, 2);
                    sHTMLContent = PopoverHelper.createHTMLContent(aSelectedItems, oParentContext.oVizProperties.plotArea.dataPointStyle.rules, "", 2);

                    return new sap.ui.core.HTML({ content: sHTMLContent });
                }
            });

            return oParentContext._popover;
        },

        /**
          * `Adds the feeds to the chart to display capacity info
          *
          * @public
          * @return {void}
         */
        _addFeeds: function() {
            var feedValueAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
                    "uid": "valueAxis",
                    "type": "Measure",
                    "values": ["OpenDays", "NonDays", "ProDays"]
                }),
                feedCategoryAxis = new sap.viz.ui5.controls.common.feeds.FeedItem({
                    "uid": "categoryAxis",
                    "type": "Dimension",
                    "values": [i18nCapacity.getText("FRAGMENT_STAFFED_DEMAND_CHART_DIMENSION_COE_ORGANISATION")]
                });

            this.oVizFrame.addFeed(feedValueAxis);
            this.oVizFrame.addFeed(feedCategoryAxis);
        }

    };
});
