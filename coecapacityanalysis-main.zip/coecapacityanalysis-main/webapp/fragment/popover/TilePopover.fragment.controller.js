sap.ui.define([
    "sap/ui/core/mvc/Controller",
], function(Controller, TextArea) {
    "use strict";


    return Controller.extend("sap.coe.capacity.analysis.fragment.popover.TilePopover", {


        onBeforeOpen: function(oEvent) {
           
        }

    });

});
