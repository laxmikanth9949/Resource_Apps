sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/TablePersoController",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/coe/capacity/analysis/fragment/StaffedDemand.fragment.helper",
    "sap/coe/capacity/analysis/fragment/TeamOverview.fragment.helper",
    "sap/coe/capacity/analysis/fragment/StaffedDetails.fragment.helper",
    "sap/coe/capacity/analysis/util/dateHelper",
    "sap/coe/capacity/analysis/util/formatter",
    "sap/coe/capacity/analysis/util/i18n",
    "sap/coe/capacity/reuselib/utils/VariantFilterHelper",
    "sap/coe/capacity/analysis/fragment/popover/TilePopover.fragment.controller",
    "sap/coe/capacity/reuselib/utils/helpers",
    "sap/coe/capacity/reuselib/controls/CustomVariantManager/CustomVariantManagerComponent",
    "sap/coe/capacity/analysis/util/DataManager",
    "sap/coe/capacity/reuselib/utils/DataManager",
    "sap/m/MessageBox"
], function(Controller, TablePersoController, JSONModel, MessageToast, oStaffedDemand, oTeamOverview, oStaffedDetails, dateHelper,
    formatter, i18nCapacity, VariantHelper, TilePopoverController, helpers, CustomVariantManager, DataManager, DataManagerReuse, MessageBox) {
    "use strict";

    var oMasterController;

    return Controller.extend("sap.coe.capacity.analysis.view.Master", {
        VariantHelper: VariantHelper,
        formatter: formatter,

        /**
         * Initilises the application
         *
         * @public
         * @return {void}
         */
        onInit: function() {
            SVGElement.prototype.getTransformToElement = SVGElement.prototype.getTransformToElement || function(elem) {
                return elem.getScreenCTM().inverse().multiply(this.getScreenCTM());
            };

            oMasterController = this;
            this._oView = this.getView();
            this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this._oView));

            VariantHelper.setVariantFilterModel(this._oView);
            oStaffedDemand.onInit(this);
            oTeamOverview.onInit(this);
            oStaffedDetails.onInit(this);
            this._setUtilsModelToView();
            this._initCWSlider();
        },

        /**
         * Called before the application has finished rendering
         *
         * @public
         * @return {void}
         */
        onBeforeRendering: function() {
            this.byId("masterFilterBar").fireInitialise();
        },

        /**
         * Called after the application has finished rendering
         *
         * @public
         * @return {void}
         */
        onAfterRendering: function() {
            oStaffedDemand.byId("RangeSlider--idForMasterSlider-text4");
        },

        /**
         * Initialises the filter bar on application load
         *
         * @public
         * @param {Object} oEvent - the object which called the function
         * @return {void}
         */
        onInitialiseFilterBar: function(oEvent) {
            var that = oMasterController,
                oFilterBar = oEvent.getSource();

            if (oFilterBar.customVariantManager === undefined){
                oFilterBar.customVariantManager = new CustomVariantManager({
                    appId: "SAP.COE.CAPACITY.ANALYSISPilot05",
                    variantSet: "CAPACITYANALYSISPilot05",
                    defaultVariant: that._getDefaultVariant,
                    filterBar: oFilterBar
                });
            }
        },

        /**
         * Updates the chart bindings in StaffedDetails tab based off the users selection from the dropdown
         *
         * @public
         * @param {Object} oEvent - the object which called the function
         * @return {void}
         */
        onStaffedDetailsSelectionChange: function(oEvent) {
            oStaffedDetails.updateChartBinding(oEvent.getSource().getSelectedKey());
        },

        /**
         * Loads the fragment for the tab the user has selected
         *
         * @public
         * @param {Object} oEvent - the object which called the function
         * @return {void}
         */
        onPressIconTab: function(oEvent) {
            var key = oEvent.getSource().getSelectedKey();
            if (key === "staffedDemand") {
                oStaffedDemand.onLoadTab();
            } else if (key === "teamOverview") {
                oTeamOverview.onLoadTab();
            }
        },

        /**
         * Opens the popover when user clicks on a tile
         *
         * @public
         * @param {Object} oEvent - the object which called the function
         * @return {void}
         */
        onTilePopoverOpen: function(oEvent) {
            this._openPopover(oEvent, oEvent.getSource(), "Bottom");
        },

        /**
         * Opens the popover when user clicks on a icon/button
         *
         * @public
         * @param {Object} oEvent - the object which called the function
         * @return {void}
         */
        onIconPopoverOpen: function(oEvent) {
            this._openPopover(oEvent, oEvent.getSource().getParent(), "Top");
        },

        closeQualifications: function() {
            oTeamOverview.closeQualifications();
        },

        /**
         * Updates the data filter if user changes the date range on CW slider
         *
         * @public
         * @param {Object} oEvent - the object which called the function
         * @return {void}
         */
        onSliderChange: function(oEvent) {
            var oDateRangeSelect = this.byId("idForStartEndDate"),
                oFilterBar = this.getView().byId("masterFilterBar"),
                iValue1 = oEvent.getParameter("value"),
                iValue2 = oEvent.getParameter("value2"),
                oDates = oEvent.getSource().getModel("CWModel").getProperty("/WeekDate"),
                oStartDate = dateHelper.getCurrentWeekFromDate(oDates[iValue1])[0],
                oEndDate = dateHelper.getCurrentWeekFromDate(oDates[iValue2])[1];
            oDateRangeSelect.setDateValue(oStartDate);
            oDateRangeSelect.setSecondDateValue(oEndDate);
            oFilterBar.search();
        },

        /**
         * Expands the filterbar when the user has closed the filter dialog
         *
         * @public
         * @param {Object} oEvent - the object which called the function
         * @return {void}
         */
        onFiltersDialogClosed: function(oFilterBar) {
            var oSource = oFilterBar.getSource();
            oSource.setFilterBarExpanded(true);
        },

        /**
         * Takes the inputted filters and reads in the required data
         *
         * @public
         * @param {Object} oEvent - the object which called the function
         * @return {void}
         */
        onFilterBarSearchButtonPressed: function(oEvent) {
            var oStaffedDemandTiles = oStaffedDemand.byId("idForHBox"),
                oStaffedDemandChart = oStaffedDemand.byId("idVizFrame"),
                oTeamOverviewChart = oTeamOverview.byId("idVizFrame"),
                oTeamOverviewTile = oTeamOverview.byId("idForHBox"),
                oStaffedDetailsTiles = oStaffedDetails.byId("idForHBox"),
                oStaffedDetailsChart = oStaffedDetails.byId("idVizFrame"),
                oStaffedDetailsTable = oStaffedDetails.byId("idForTable"),
                bMandatoryFieldsProvided = false;

            this.aCurrentFilters = VariantHelper.getFiltersSimple(oEvent);
            bMandatoryFieldsProvided = this._checkFilters(this.aCurrentFilters);

            if (this.aCurrentFilters.length > 0 && bMandatoryFieldsProvided) {
                this.aCurrentFilters[0].sPath = "BegDate";
                var aOrgFilters = this._getOrgIdFilters(this.aCurrentFilters),
                    aStaffedDetailsChartFilters = this._getChartsFilters(this.aCurrentFilters);
                // TODO: _oComponent is temp fix
                oStaffedDemandTiles.setBusy(true);
                oStaffedDetailsTiles.setBusy(true);
                DataManager.onReadCapacityData(this.oView.oController._oComponent.getModel(), this.aCurrentFilters, this.onResponseCapacity, this.onErrorCapacity);

                oTeamOverviewChart.setBusy(true);
                oTeamOverviewTile.setBusy(true);
                DataManager.onReadTeamOverviewData(this.oView.oController._oComponent.getModel(), this.aCurrentFilters, this.onResponseTeamOverview, this.onErrorTeamOverview);

                oStaffedDetailsChart.setBusy(true);
                oStaffedDetailsTable.setBusy(true);
                DataManager.onReadRoleData(this.oView.oController._oComponent.getModel(), aStaffedDetailsChartFilters, this.onResponseRole, this.onErrorRole);
                DataManager.onReadServiceData(this.oView.oController._oComponent.getModel(), aStaffedDetailsChartFilters, this.onResponseServices, this.onErrorServices);
                DataManager.onReadQualificationData(this.oView.oController._oComponent.getModel(), aStaffedDetailsChartFilters, this.onResponseQualifications, this.onErrorQualifications);
                DataManager.onReadNonProdData(this.oView.oController._oComponent.getModel(), aStaffedDetailsChartFilters, this.onResponseNonProd, this.onErrorNonProd);
                DataManager.onReadActivityData(this.oView.oController._oComponent.getModel(), aStaffedDetailsChartFilters, this.onResponseActivity, this.onErrorActivity);
                DataManager.onReadResourceOriginData(this.oView.oController._oComponent.getModel(), aStaffedDetailsChartFilters, this.onResponseResourceOrigin, this.onErrorResourceOrigin);

                oStaffedDemandChart.setBusy(true);
                DataManager.onReadSubUnitData(this.oView.oController._oComponent.getModel(), aOrgFilters, this.onResponseSubUnit, this.onErrorSubUnit);

                oStaffedDetails.byId("idForSelectChartDimension").setEnabled(false);
            } else {
                this._clearAll();
            }
        },

        /**
         * Retrieve the current frontend filters selected
         *
         * @public
         * @return {Array} - the current filters selected
         */
        getFilters: function() {
            return this.aCurrentFilters;
        },

        /**
         * Handles the response returned from the Capacity service
         *
         * @public
         * @param {Object} odata - the data returned from the service
         * @param {Object} response - the response returned from the service
         * @return {void}
         */
        onResponseCapacity: function(odata, response) {
            oStaffedDemand.byId("idForHBox").setBusy(false);
            oTeamOverview.byId("idForHBox").setBusy(false);
            oStaffedDetails.byId("idForHBox").setBusy(false);
            oStaffedDemand.onResponseCapacity(response.data.results[0]);
            oTeamOverview.onResponseCapacity(response.data.results[0]);
            oStaffedDetails.onResponseCapacity(response.data.results[0]);
        },

        /**
         * Handles an error response returned from the Capacity service
         *
         * @public
         * @param {Object} oResponse - the response returned from the service
         * @return {void}
         */
        onErrorCapacity: function(oResponse) {
            oStaffedDemand.byId("idForHBox").setBusy(false);
            oTeamOverview.byId("idForHBox").setBusy(false);
            oStaffedDetails.byId("idForHBox").setBusy(false);
            oStaffedDemand.onResponseCapacity({});
            oTeamOverview.onResponseCapacity({});
            oStaffedDetails.onResponseCapacity({});
            DataManager.onErrorResponse(oResponse);
        },

        /**
         * Handles the response returned from the SubUnit service
         *
         * @public
         * @param {Object} odata - the data returned from the service
         * @param {Object} response - the response returned from the service
         * @return {void}
         */
        onResponseSubUnit: function(odata, response) {
            oStaffedDemand.byId("idVizFrame").setBusy(false);
            oStaffedDemand.onResponseSubUnit(response.data.results);
        },

        /**
         * Handles an error response returned from the SubUnit service
         *
         * @public
         * @param {Object} oResponse - the response returned from the service
         * @return {void}
         */
        onErrorSubUnit: function(oResponse) {
            oStaffedDemand.byId("idVizFrame").setBusy(false);
            oStaffedDemand.onResponseSubUnit([]);
            DataManager.onErrorResponse(oResponse);
        },

        /**
         * Handles the response returned from the TeamOverview service
         *
         * @public
         * @param {Object} odata - the data returned from the service
         * @param {Object} response - the response returned from the service
         * @return {void}
         */
        onResponseTeamOverview: function(oData, oResponse) {
            oTeamOverview.byId("idVizFrame").setBusy(false);
            oTeamOverview.onResponseData(oData.results);
        },

        /**
         * Handles an error response returned from the TeamOverview service
         *
         * @public
         * @param {Object} oResponse - the response returned from the service
         * @return {void}
         */
        onErrorTeamOverview: function(oResponse) {
            oTeamOverview.byId("idVizFrame").setBusy(false);
            oTeamOverview.onResponseData([]);
            DataManager.onErrorResponse(oResponse);
        },

        /**
         * Handles the response returned from the Role service
         *
         * @public
         * @param {Object} odata - the data returned from the service
         * @param {Object} response - the response returned from the service
         * @return {void}
         */
        onResponseRole: function(oData, oResponse) {
            oStaffedDetails.byId("idVizFrame").setBusy(false);
            oStaffedDetails.byId("idForTable").setBusy(false);
            oStaffedDetails.byId("idForSelectChartDimension").setEnabled(true);
            oStaffedDetails.onResponseRoleData(oData.results);
        },

        /**
         * Handles an error response returned from the Role service
         *
         * @public
         * @param {Object} oResponse - the response returned from the service
         * @return {void}
         */
        onErrorRole: function(oResponse) {
            oStaffedDetails.byId("idVizFrame").setBusy(false);
            oStaffedDetails.byId("idForTable").setBusy(false);
            oStaffedDetails.byId("idForSelectChartDimension").setEnabled(true);
            oStaffedDetails.onResponseRoleData([]);
            DataManager.onErrorResponse(oResponse);
        },

        /**
         * Handles the response returned from the Services service
         *
         * @public
         * @param {Object} odata - the data returned from the service
         * @param {Object} response - the response returned from the service
         * @return {void}
         */
        onResponseServices: function(oData, oResponse) {
            oStaffedDetails.byId("idVizFrame").setBusy(false);
            oStaffedDetails.byId("idForTable").setBusy(false);
            oStaffedDetails.onResponseServiceData(oData.results);
        },

        /**
         * Handles an error response returned from the Services service
         *
         * @public
         * @param {Object} oResponse - the response returned from the service
         * @return {void}
         */
        onErrorServices: function(oResponse) {
            oStaffedDetails.byId("idVizFrame").setBusy(false);
            oStaffedDetails.byId("idForTable").setBusy(false);
            oStaffedDetails.onResponseServiceData([]);
            DataManager.onErrorResponse(oResponse);
        },

        /**
         * Handles the response returned from the Qualifications service
         *
         * @public
         * @param {Object} odata - the data returned from the service
         * @param {Object} response - the response returned from the service
         * @return {void}
         */
        onResponseQualifications: function(oData, oResponse) {
            oStaffedDetails.byId("idVizFrame").setBusy(false);
            oStaffedDetails.byId("idForTable").setBusy(false);
            oStaffedDetails.onResponseQualificationData(oData.results);
        },

        /**
         * Handles an error response returned from the Qualification service
         *
         * @public
         * @param {Object} oResponse - the response returned from the service
         * @return {void}
         */
        onErrorQualifications: function(oResponse) {
            oStaffedDetails.byId("idVizFrame").setBusy(false);
            oStaffedDetails.byId("idForTable").setBusy(false);
            oStaffedDetails.onResponseQualificationData([]);
            DataManager.onErrorResponse(oResponse);
        },

        /**
         * Handles the response returned from the NonProd service
         *
         * @public
         * @param {Object} odata - the data returned from the service
         * @param {Object} response - the response returned from the service
         * @return {void}
         */
        onResponseNonProd: function(oData, oResponse) {
            oStaffedDetails.byId("idVizFrame").setBusy(false);
            oStaffedDetails.byId("idForTable").setBusy(false);
            oStaffedDetails.onResponseNonProdData(oData.results);
        },

        /**
         * Handles an error response returned from the NonProd service
         *
         * @public
         * @param {Object} oResponse - the response returned from the service
         * @return {void}
         */
        onErrorNonProd: function(oResponse) {
            oStaffedDetails.byId("idVizFrame").setBusy(false);
            oStaffedDetails.byId("idForTable").setBusy(false);
            oStaffedDetails.onResponseNonProdData([]);
            DataManager.onErrorResponse(oResponse);
        },

        /**
         * Handles the response returned from the Activity service
         *
         * @public
         * @param {Object} odata - the data returned from the service
         * @param {Object} response - the response returned from the service
         * @return {void}
         */
        onResponseActivity: function(oData, oResponse) {
            oStaffedDetails.byId("idVizFrame").setBusy(false);
            oStaffedDetails.byId("idForTable").setBusy(false);
            oStaffedDetails.onResponseActivityData(oData.results);
        },

        /**
         * Handles an error response returned from the Activity service
         *
         * @public
         * @param {Object} oResponse - the response returned from the service
         * @return {void}
         */
        onErrorActivity: function(oResponse) {
            oStaffedDetails.byId("idVizFrame").setBusy(false);
            oStaffedDetails.byId("idForTable").setBusy(false);
            oStaffedDetails.onResponseActivityData([]);
            DataManager.onErrorResponse(oResponse);
        },

        /**
         * Handles the response returned from the ResourceOrigin service
         *
         * @public
         * @param {Object} odata - the data returned from the service
         * @param {Object} response - the response returned from the service
         * @return {void}
         */
        onResponseResourceOrigin: function(oData, oResponse) {
            oStaffedDetails.byId("idVizFrame").setBusy(false);
            oStaffedDetails.byId("idForTable").setBusy(false);
            oStaffedDetails.onResponseResourceOriginData(oData.results);
        },

        /**
         * Handles an error response returned from the ResourceOrigin service
         *
         * @public
         * @param {Object} oResponse - the response returned from the service
         * @return {void}
         */
        onErrorResourceOrigin: function(oResponse) {
            oStaffedDetails.byId("idVizFrame").setBusy(false);
            oStaffedDetails.byId("idForTable").setBusy(false);
            oStaffedDetails.onResponseResourceOriginData([]);
            DataManager.onErrorResponse(oResponse);
        },

        /**
         * Calls the Qualification view service with the modified filters
         *
         * @public
         * @param {Array} aFilters - the filters retrieved from the TeamOverview fragment
         * @return {void}
         */
        readQualificationViewData: function(oCwDates) {
            oTeamOverview.byId("idVizFrame").setBusy(true);
            DataManager.onReadQualViewData(this.oView.oController._oComponent.getModel(), this.aCurrentFilters, this.onResponseQualificationView, this.onErrorQualificationView);
        },

        /**
         * Handles the response returned from the Qualification view service
         *
         * @public
         * @param {Object} oData - the data returned from the service
         * @param {Object} oResponse - the response returned from the service
         * @return {void}
         */
        onResponseQualificationView: function(oData, oResponse) {
            oTeamOverview.byId("idVizFrame").setBusy(false);
            oTeamOverview.onResponseQualData(oData.results);
        },

        /**
         * Handles an error response returned from the Qualification view service
         *
         * @public
         * @param {Object} oResponse - the response returned from the service
         * @return {void}
         */
        onErrorQualificationView: function(oResponse) {
            oTeamOverview.byId("idVizFrame").setBusy(false);
            oTeamOverview.onResponseQualData([]);
            DataManager.onErrorResponse(oResponse);
        },

        _getDefaultVariant: function() {
            var that = oMasterController,
                oFilterBar = that.getView().byId("masterFilterBar"),
                oDefaultVariant = {};

            that.getView().getModel().read("/OrgUnitSet(EmpId='',OrgId='')", {
                urlParameters: {
                    "$expand": "SubOrgUnitSet",
                    "$format": "json"
                },
                success: function(oData, response) {
                    oDefaultVariant.OrgId = [{
                        id: oData.OrgId,
                        name: oData.OrgText
                    }];
                    oFilterBar.customVariantManager.createDefaultVariant(oDefaultVariant);
                }
            });
        },

        _initCWSlider: function() {
            var oMasterSlider = oStaffedDemand.byId("RangeSlider--idForMasterSlider"),
                sCurrentCW = dateHelper.getCurrentCalendarWeek(),
                oDatesCurrentWeek = dateHelper.getDateRangeFromCalendarWeek(sCurrentCW),
                oData = dateHelper.getCWModel(oDatesCurrentWeek.startDate, 5, 30, 4, 11),
                oCWLabelData = this._calculateCWWidth(oData);

            oData.beginYear = oCWLabelData.iStartYear;
            if (oCWLabelData.leftWidthInPercent < 100) {
                oData.endYear = oCWLabelData.iEndYear;
            }
            oData.rightWidthInPercent = oCWLabelData.rightWidthInPercent + "%";
            oData.leftWidthInPercent = oCWLabelData.leftWidthInPercent + "%";

            this._oView.setModel(new JSONModel(oData), "CWModel");
            oMasterSlider.fireChange({
                value: 4,
                value2: 11
            });
        },

        _getOrgIdFilters: function(aFilters) {
            var aOrgIds = [];
            for (var i = 0; i < aFilters.length; i++) {
                if (aFilters[i].sPath === "OrgId") {
                    aOrgIds.push(aFilters[i]);
                } else if (aFilters[i].sPath === "BegDate") {
                    aOrgIds.push(aFilters[i]);
                } else if (aFilters[i].sPath === "EndDate") {
                    aOrgIds.push(aFilters[i]);
                }
            }
            return aOrgIds;
        },

        _getChartsFilters: function(aFilters) {
            var aChartsFilter = [];

            for (var i = 0; i < aFilters.length; i++) {
                if (aFilters[i].sPath === "OrgId") {
                    aChartsFilter.push(aFilters[i]);
                } else if (aFilters[i].sPath === "BegDate") {
                    aChartsFilter.push(aFilters[i]);
                } else if (aFilters[i].sPath === "EndDate") {
                    aChartsFilter.push(aFilters[i]);
                } else if (aFilters[i].sPath === "ResServiceArea") {
                    aChartsFilter.push(aFilters[i]);
                } else if (aFilters[i].sPath === "ResServiceTeam") {
                    aChartsFilter.push(aFilters[i]);
                } else if (aFilters[i].sPath === "ResQualification") {
                    aChartsFilter.push(aFilters[i]);
                }
            }

            return aChartsFilter;
        },

        _calculateCWWidth: function(oDataCW) {
            var iLeftWidthInPercent = 0,
                iRightWidthInPercent = 0,
                iAmountOfCWInStartYear = 0,
                iStartYear = oDataCW.WeekDate[0].getFullYear(),
                iEndYear = oDataCW.WeekDate[oDataCW.WeekDate.length - 1].getFullYear();


            for (var i = 0; i < oDataCW.WeekDate.length; i++) {
                if (iStartYear !== oDataCW.WeekDate[i].getFullYear()) break;
                iAmountOfCWInStartYear++;
            }

            iLeftWidthInPercent = (iAmountOfCWInStartYear / oDataCW.WeekDate.length) * 100;
            iRightWidthInPercent = 100 - iLeftWidthInPercent;

            return {
                "leftWidthInPercent": iLeftWidthInPercent,
                "rightWidthInPercent": iRightWidthInPercent,
                "iStartYear": iStartYear,
                "iEndYear": iEndYear
            };
        },

        _checkFilters: function(aFilters) {
            var iOrgUnit = 0;
            var iDemandServiceTeam = 0;

            aFilters.forEach(function(oElement) {
                if (oElement.sPath === "OrgId") iOrgUnit++;
                else if (oElement.sPath === "DemandServiceTeam") iDemandServiceTeam++;
            });

            if ((iOrgUnit < 1) || (iDemandServiceTeam < 1)) {
                MessageToast.show(i18nCapacity.getText("MASTER_VIEW_ERROR_MSG_SELECT_ORG_UNIT_DEMAND_SERVICE_TEAM"), {
                    duration: 5000,
                    width: "25em"
                });
                return false;
            }
            return true;
        },

        _clearAll: function() {
            oStaffedDemand.onResponseSubUnit([]);
            oStaffedDemand.onResponseCapacity(null);

            oTeamOverview.onResponseData([]);
            oTeamOverview.onResponseCapacity({});

            oStaffedDetails.onResponseRoleData([]);
            oStaffedDetails.onResponseServiceData([]);
            oStaffedDetails.onResponseQualificationData([]);
            oStaffedDetails.onResponseNonProdData([]);
            oStaffedDetails.onResponseActivityData([]);
            oStaffedDetails.onResponseCapacity(null);
        },

        _openPopover: function(oEvent, oTargetElement, sPlacement) {
            var oCustomTile = oEvent.getSource().data("textAreaData");
            if (!this._oDialogForIcon) {
                this._oDialogForIcon = helpers.initializeFragmentFromObject({
                    oParentController: this,
                    sFragment: "sap.coe.capacity.analysis.fragment.popover.TilePopover",
                    ControllerClass: TilePopoverController,
                    sCreateId: this.getView().createId("idForTilePopover")

                });
            }
            var oPopover = this._oDialogForIcon.byId("formattedViewId");
            oPopover.bindProperty("htmlText", "UtilsModel>/" + oCustomTile);
            this._oDialogForIcon.setPlacement(sPlacement);
            this._oDialogForIcon.openBy(oTargetElement);
        },

        _setUtilsModelToView: function() {
            this.getView().setModel(
                new sap.ui.model.json.JSONModel(jQuery.sap.getModulePath("sap.coe.capacity.analysis") + "/model/utilsModel.json"),
                "UtilsModel");
        },

        retrieveOrgUnit: function(oEvent) {
            var oFragment = oEvent.getParameter("oFragment");
            var orgUnit = "";
            var bNavBack = oEvent.getParameter("bNavBack");
            if (bNavBack) {
                orgUnit = this.oOrgNavigation[this.oOrgNavigation.length - 1].id;
            } else if (bNavBack === false) {
                var sSelectedPath = oEvent.getParameter("sSelectedPath");
                orgUnit = this._oView.getModel("OrgUnitModel").getProperty(sSelectedPath).OrgId;
                this.oOrgNavigation.pop();
            } else {
                orgUnit = bNavBack;
            }
            DataManagerReuse.getOrgUnit(this._sUser, orgUnit, oFragment, this);
        }

    });

});
