sap.ui.define([
    "sap/ui/test/opaQunit"
], function(opaTest) {
    "use strict";

    QUnit.module("StaffedDemandTab");

    opaTest("Should see the Staffed Demand when Tab is clicked.", function(Given, When, Then) {
        Given.iStartTheApp();
        When.onCapacityAnalysisPage.Init();
        When.onCapacityAnalysisPage.iClickOnIconTabFilter("staffedDemand");
        Then.onCapacityAnalysisPage.iShouldSeeATileFor("StaffedDemand");
    });

    opaTest("Should see the filter bar when show FilterBar button is pressed", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iPressButton("masterFilterBar-btnShowHide", false, "Show FilterBar button press successful", "Show FilterBar button press failed");
        Then.onCapacityAnalysisPage.iShouldSeeFilterBarOpen();

    });

    opaTest("Select the Go button on the filter bar to load the chart", function(Given, When, Then) {
        Then.onCapacityAnalysisPage.iShouldSeeVizFrameChart("StaffedDemand");
    });

    opaTest("Should see popover when the tile is clicked", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iPressOnTheTile("StaffedDemand");
        Then.onCapacityAnalysisPage.iShouldSeeAPopover();
    });

    opaTest("Tear down and clean context", function(Given, When, Then) {
        Given.iTeardownMyAppFrame();
        Then.onCapacityAnalysisPage.okAssert("FilterBar, StaffedDemandTab context cleaned");
    });

});