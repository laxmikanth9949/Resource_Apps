sap.ui.define([
    "sap/ui/test/opaQunit"
], function(opaTest) {
    "use strict";

    QUnit.module("StaffedDetailsTab");

    opaTest("Should see a Staffed Details Tile when Staffed Details Tab is clicked.", function(Given, When, Then) {
        Given.iStartTheApp();
        When.onCapacityAnalysisPage.Init();
        When.onCapacityAnalysisPage.iClickOnIconTabFilter("staffedDetails");
        Then.onCapacityAnalysisPage.iShouldSeeATileFor("staffedDetails");
    });

    opaTest("Should see the filter bar when show FilterBar button is pressed", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iPressButton("masterFilterBar-btnShowHide", false, "Show FilterBar button press successful", "Show FilterBar button press failed");
        Then.onCapacityAnalysisPage.iShouldSeeFilterBarOpen();
    });

    opaTest("Should see a table when displaying table view", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iPressOnIcon("", "sap-icon://table-chart");
        Then.onCapacityAnalysisPage.iShouldSeeATable();
    });

    opaTest("Should update the information displayed when selecting from the combobox", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iSelectOptionInComboBox("services", "idForSelectChartDimension");
        Then.onCapacityAnalysisPage.iShouldSeeCellWithValueInTable("SAP CQC for Implementation", "idForTable");
    });

    opaTest("Should see a chart when displaying chart view", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iPressOnIcon("", "sap-icon://horizontal-bar-chart");
        Then.onCapacityAnalysisPage.iShouldSeeVizFrameChart("StaffedDetails");
    });

    opaTest("Should see popover when the information button of the chart is clicked", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iPressOnIcon("", "sap-icon://message-information");
        Then.onCapacityAnalysisPage.iShouldSeeAPopover();
    });

    opaTest("Should see popover when the Demand Analysis tile is clicked", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iPressOnTheTile("demandAnalysis");
        Then.onCapacityAnalysisPage.iShouldSeeAPopover();
    });

    opaTest("Should see popover when the Staffed Demand tile is clicked", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iPressOnTheTile("staffedDemand");
        Then.onCapacityAnalysisPage.iShouldSeeAPopover();
    });

    opaTest("Should see popover when the Customer Served tile is clicked", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iPressOnTheTile("customersServed");
        Then.onCapacityAnalysisPage.iShouldSeeAPopover();
    });

    opaTest("Should see popover when the Covered Qualifications tile is clicked", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iPressOnTheTile("coveredQualifications");
        Then.onCapacityAnalysisPage.iShouldSeeAPopover();
    });

    opaTest("Should see popover when the Demand Analysis tile is clicked", function(Given, When, Then) {
        When.onCapacityAnalysisPage.iPressOnTheTile("demandAnalysis");
        Then.onCapacityAnalysisPage.iShouldSeeAPopover();
    });

    opaTest("Tear down and clean context", function(Given, When, Then) {
        Given.iTeardownMyAppFrame();
        Then.onCapacityAnalysisPage.okAssert("FilterBar, StaffedDetailsTab context cleaned");
    });

});
