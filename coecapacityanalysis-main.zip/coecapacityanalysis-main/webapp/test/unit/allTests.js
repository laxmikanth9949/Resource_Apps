sap.ui.define([
    "test/unit/fragment/TeamOverview.fragment.helper"
], function() { "use strict"; });
