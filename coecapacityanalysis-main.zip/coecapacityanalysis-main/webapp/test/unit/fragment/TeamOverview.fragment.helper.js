sap.ui.define([
    "sap/coe/capacity/analysis/fragment/TeamOverview.fragment.helper"
], function(oTeamOverviewFragmentHelper) {
    "use strict";

    QUnit.module("Fragment - TeamOverviewFragmentHelper", {
        beforeEach: function() {
            this.TeamOverviewFragmentHelper = oTeamOverviewFragmentHelper;
        }
    });

    QUnit.test("Should be possible to create an instance", function(assert) {
        assert.ok(this.TeamOverviewFragmentHelper, "Was possible to create the instance");
        assert.strictEqual(this.TeamOverviewFragmentHelper.sFragmentId, "TeamOverview", "Was created with the expected id");
    });

});
