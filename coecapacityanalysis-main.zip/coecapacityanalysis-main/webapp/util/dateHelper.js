jQuery.sap.declare("sap.coe.capacity.analysis.util.dateHelper");
sap.coe.capacity.analysis.util.dateHelper = {};

/**
 * From a Date obj. returns CW number
 *
 * @public
 * @param {object} Date obj.
 * @param {int} number of weeks previous
 * @param {int} total number of weeks
 * @returns {object} Date obj. array
 */

sap.coe.capacity.analysis.util.dateHelper.getCWModel = function(oDate, iCWPre, iCWTotal, iValue1, iValue2) {
    var oStartDate = new Date(oDate.setDate(oDate.getDate() - (iCWPre * 7))),
        oModel = {
            WeekDate: [],
            value1: iValue1,
            value2: iValue2
        };

    for (var i = 0; i < iCWTotal; i++) {
        oModel.WeekDate.push(oStartDate);
        oStartDate = new Date(oStartDate.setDate(oStartDate.getDate() + 7));
    }
    return oModel;
};

/**
 * Return the calendar week of a date. The ISO 8601 definition for week 01 is the week with the year's first Thursday in it.
 * https://en.wikipedia.org/wiki/ISO_week_date
 *
 * @public
 *
 * @param {Date} oDate The date.
 *
 * @returns {string} sCW The calendar week
 */
sap.coe.capacity.analysis.util.dateHelper.getCWFromDate = function(dDate) {
    var dTime,
        dCheckDate = new Date(dDate.getTime());

    // Find Thursday of this week starting on Monday
    dCheckDate.setDate(dCheckDate.getDate() + 4 - (dCheckDate.getDay() || 7));

    dTime = dCheckDate.getTime();
    dCheckDate.setMonth(0); // Compare with Jan 1
    dCheckDate.setDate(1);
    return (Math.floor(Math.round((dTime - dCheckDate) / 86400000) / 7) + 1).toString();
};

/**
 * From an array of Date obj. returns CW number
 *
 * @public
 * @param {array} array of Date obj.
 * @returns {array} [CW numbers]
 */

sap.coe.capacity.analysis.util.dateHelper.getCWFromDateArray = function(aDates) {
    var aCalWs = [];
    for (var i = 0; i < aDates.length; i++) {
        aCalWs.push(sap.coe.capacity.analysis.util.dateHelper.getCWFromDate(aDates[i]));
    }
    return aCalWs;
};


/**
 * Gets a calendar week date range from supplied date obj
 *
 * @public
 * @param {object} oDate the date of the CW
 * @returns {array} [start of CW, end of CW]
 */
sap.coe.capacity.analysis.util.dateHelper.getCurrentWeekFromDate = function(oDate) {
    var start = start || 1,
        dToday = new Date(oDate.setHours(0, 0, 0, 0)),
        day = dToday.getDay() - start,
        date = dToday.getDate() - day,
        dStartDate = new Date(dToday.setDate(date)),
        dEndDate = new Date(dStartDate.getFullYear(), dStartDate.getMonth(), dStartDate.getDate() + 7 - dStartDate.getDay());
    
    return [dStartDate, dEndDate];
};

/**
 * Return the date range of a calendar week taking into account the current date
 *
 * @public
 *
 * @param {string} sCW The calendar week
 *
 * @returns {object}    obj.startDate Date object with the first day of the calendar week
 *                      obj.endDate Date object with the last day of the calendar week
 */
sap.coe.capacity.analysis.util.dateHelper.getDateRangeFromCalendarWeek = function(sCW) {
    var iCW = parseInt(sCW, 10),
        iCurrentCW = parseInt(this.getCurrentCalendarWeek(), 10),
        iYear,
        iFirstWeekDayNumberOfYear,
        oFirstDayOfYear,
        iMilisecondsToTheMondayOfCW,
        iCWToCount = iCW;

    // CW in the previous year
    // check if current week - chosen week < 0 && chosen week > current week + 25 (max value on the slider)
    // eg, current week is 2, week chosen is 52, 2 - 52 = -50 which less than 0, 52 > 27 (2+25)
    if (((iCurrentCW - iCW) < 0) && (iCW > (iCurrentCW + 25))) {
        iYear = new Date().getFullYear() - 1;
    }
    // CW in the next year
    // check if current week - chosen week > 0 && current week - chosen week > 25
    // eg, current week is 50, week chosen is 4, 50 - 4 = 46 which greater than 0, and 50 - 4 is greater than 25
    else if (((iCurrentCW - iCW) > 0) && (iCurrentCW - iCW > 25)) {
        iYear = new Date().getFullYear() + 1;
    }
    else {
        iYear = new Date().getFullYear();
    }

    iFirstWeekDayNumberOfYear = new Date(iYear, 0, 1).getDay() ? new Date(iYear, 0, 1).getDay() : 7;
    oFirstDayOfYear = new Date("Jan 01, " + iYear + " 00:00:00");
    if(iFirstWeekDayNumberOfYear < 5) {
        // we don't need to calculate a week since the first day is in the first week already
        iCWToCount -= 1;
    }
    iMilisecondsToTheMondayOfCW = oFirstDayOfYear.getTime() - (3600000 * 24 * (iFirstWeekDayNumberOfYear - 1)) + 604800000 * iCWToCount;

    return {
        startDate: new Date(iMilisecondsToTheMondayOfCW),
        endDate: new Date(iMilisecondsToTheMondayOfCW + 518400000)
    };
};

/**
 * Return the current calendar week. The ISO 8601 definition for week 01 is the week with the year's first Thursday in it.
 * https://en.wikipedia.org/wiki/ISO_week_date
 *
 * @public
 *
 * @returns {String} sCurrentCW The current calendar week
 */
sap.coe.capacity.analysis.util.dateHelper.getCurrentCalendarWeek = function() {
    return this.getCWFromDate(new Date());
};
