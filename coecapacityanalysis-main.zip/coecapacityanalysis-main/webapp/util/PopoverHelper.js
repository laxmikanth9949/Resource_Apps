sap.ui.define([], function() {
    "use strict";

    var PopoverHelper = {};

    PopoverHelper.createHTMLContent = function(aSelectedItems, oVizStyleRules, sTitle, iIndexOfPropertyName) {
        var sHTMLContent = "<div style ='margin-top: 15px;'></div><table style='width:100%; margin-left: 10px;'>",
            sPropertyName,
            sDisplayName,
            sColorCode,
            iDaysInPercentage,
            sDivBottomMargin = "<div style ='margin-top: 15px;'></div>";


        if (sTitle !== undefined && sTitle !== "") {
            sHTMLContent += "<tr><td colspan='3'><b>" + sTitle + "</b></td></tr>";
        }

        for (var i = 0; i < aSelectedItems.length; i++) {
            sPropertyName = Object.keys(aSelectedItems[i].data)[iIndexOfPropertyName];
            iDaysInPercentage = parseFloat(aSelectedItems[i].data.percentage) * 100;
            sColorCode = PopoverHelper._getColorForAttribute(sPropertyName, oVizStyleRules);
            sDisplayName = PopoverHelper._getDisplayNameForAttribute(sPropertyName, oVizStyleRules);

            sHTMLContent += PopoverHelper._chartPopoverRenderer(
                sColorCode,
                sDisplayName,
                aSelectedItems[i].data[sPropertyName],
                parseFloat(iDaysInPercentage.toFixed(0)));
        }

        sHTMLContent += "</table>";
        sHTMLContent += sDivBottomMargin;

        return sHTMLContent;
    };

    /**
     * Creates the HTML string to be used to display the selected CW in the popover
     *
     * @public
     * @param {String} sTitle - CW's to be displayed
     * @return {String} SHTMLContent - HTML syntax to be used in popover
    */
    PopoverHelper.createHTMLContentForTopRow = function(sTitle) {
        var sHTMLContent = "<div style ='margin-top: 0px;'></div><table style='width:100%; margin-left: 0px;'>",
            sDivBottomMargin = "<div style ='margin-top: 0px;'></div>";

        if (sTitle !== undefined && sTitle !== "") {
            sHTMLContent += "<tr><td colspan='3' align='middle'>" + sTitle + "</td></tr>";
        }
        sHTMLContent += "</table>";
        sHTMLContent += sDivBottomMargin;

        return sHTMLContent;
    };

    PopoverHelper.createHTMLBreakdown = function(aBreakDownData, sTitle) {
        var sHTMLContent = "<div style ='margin-top: 15px;'></div><table style='width:100%; margin-left: 10px;'>",
            iTotalCapacity = PopoverHelper._addPropertyValues(aBreakDownData, "StaffedDemDays"),
            sDivBottomMargin = "<div style ='margin-top: 15px;'></div>",
            aBreakDownDataAttributes = ["ServiceDays", "BackOfficeDays", "DevRoomDays", "Others"],
            aDisplayText = ["Service Days", "Back Office", "Deployment Room Days", "Others"],
            iDaysInPercentage = 0,
            sCurrentAttribute;

        if (sTitle !== undefined && sTitle !== "") {
            sHTMLContent += "<tr><td colspan='3'><b>" + sTitle + "</b></td></tr>";
        }

        for (var i = 0; i < aBreakDownDataAttributes.length; i++) {
            sCurrentAttribute = aBreakDownDataAttributes[i];

            if (iTotalCapacity > 0) {
                iDaysInPercentage = (PopoverHelper._addPropertyValues(aBreakDownData, sCurrentAttribute) / iTotalCapacity) * 100;
                iDaysInPercentage = parseFloat(iDaysInPercentage.toFixed(0));
            }

            sHTMLContent += "<tr>";
            sHTMLContent += "<td><div style='margin-left:10px; width:170px;'>" + aDisplayText[i] + "</div></td>";
            sHTMLContent += iDaysInPercentage ? "<td>" + PopoverHelper._addPropertyValues(aBreakDownData, sCurrentAttribute) + " Days " + iDaysInPercentage.toFixed(0) + "% of Staffed Demand</td>" : "<td>" + PopoverHelper._addPropertyValues(aBreakDownData, sCurrentAttribute) + " Days</td>";
            sHTMLContent += "</tr>";
        }

        sHTMLContent += "</table>";
        sHTMLContent += sDivBottomMargin;

        return sHTMLContent;
    };

    PopoverHelper.createHTMLDemandOvercapacity = function(aBreakDownData) {
        var sHTMLContent = "<div style ='margin-top: 15px;'></div><table style='width:100%; margin-left: 10px;'>",
            sDivBottomMargin = "<div style ='margin-top: 15px;'></div>",
            aDisplayText = "Demand Overcapacity";


        sHTMLContent += "<tr>";
        sHTMLContent += "<td style='width:193px;'><b>" + aDisplayText + "</b></td>";
        sHTMLContent += "<td>" + PopoverHelper._addPropertyValues(aBreakDownData, "DemOverCapacity") + " Days</td>";
        sHTMLContent += "</tr>";

        sHTMLContent += "</table>";
        sHTMLContent += sDivBottomMargin;

        return sHTMLContent;
    };

    PopoverHelper.combineBarValues = function(aSelectedItems, iIndexOfPropertyName) {
        var aAlreadyIncounterdValues = [],
            aCombinedItems = [],
            sCurrentItemName = "",
            iPositionInArray = -1;

        for (var i = 0; i < aSelectedItems.length; i++) {
            sCurrentItemName = Object.keys(aSelectedItems[i].data)[iIndexOfPropertyName];
            iPositionInArray = $.inArray(sCurrentItemName, aAlreadyIncounterdValues);

            if (iPositionInArray !== -1) {
                aCombinedItems[iPositionInArray].data[sCurrentItemName] += aSelectedItems[i].data[sCurrentItemName];
                continue;
            }

            aAlreadyIncounterdValues.push(sCurrentItemName);
            aCombinedItems.push(aSelectedItems[i]);
        }

        return aCombinedItems;
    };

    PopoverHelper._addPropertyValues = function(aBreakDownData, sAttributeName) {
        var iSum = 0;

        for (var i = 0; i < aBreakDownData.length; i++) {
            iSum += parseFloat(aBreakDownData[i][sAttributeName], 10);
        }

        return iSum;
    };

    PopoverHelper._chartPopoverRenderer = function(sColor, sAttributeDayName, sDays, iDaysInPercentage) {
        var sHTMLContent = "<tr>",
            iPercentage;

        if (isNaN(iDaysInPercentage) || iDaysInPercentage === Number.NEGATIVE_INFINITY || iDaysInPercentage === Number.POSITIVE_INFINITY) {
            iPercentage = 0;
        } else {
            iPercentage = iDaysInPercentage;
        }

        sHTMLContent += "<td>" + PopoverHelper._chartPopoverRendererSVG(sColor) + "</td>";
        sHTMLContent += "<td style='width:170px;'>" + sAttributeDayName + "</td>";
        sHTMLContent += iPercentage ? "<td>" + sDays + " Days " + iPercentage + "% of Total</td>" : "<td>" + sDays + " Days</td>";

        return sHTMLContent + "</tr>";
    };

    PopoverHelper._chartPopoverRendererSVG = function(sColor) {
        return "<svg width='10px' style='margin-left:10px' height='10px'><path d='M-5,-5L5,-5L5,5L-5,5Z' fill='" + sColor + "' transform='translate(5,5)'></path></svg>";
    };


    PopoverHelper._getColorForAttribute = function(sPropertyName, oVizStyleRules) {
        for (var i = 0; i < oVizStyleRules.length; i++) {
            if (oVizStyleRules[i].dataContext[sPropertyName]) {
                return oVizStyleRules[i].properties.color;
            }
        }
        return "";
    };

    PopoverHelper._getDisplayNameForAttribute = function(sPropertyName, oVizStyleRules) {
        for (var i = 0; i < oVizStyleRules.length; i++) {
            if (oVizStyleRules[i].dataContext[sPropertyName]) {
                return oVizStyleRules[i].displayName;
            }
        }
        return "";
    };

    return PopoverHelper;
});
