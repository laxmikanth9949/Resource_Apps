sap.ui.define([
    "sap/coe/capacity/analysis/util/i18n"
], function(i18n) {
    "use strict";

    var DataManager = {};

    DataManager.onReadCapacityData = function(oModel, aFilters, fRequestSuccess, fRequestError) {
        oModel.read("/ResCapacityHSet", {
            filters: aFilters,
            success: fRequestSuccess,
            error: fRequestError
        });
    };

    DataManager.onReadSubUnitData = function(oModel, aFilters, fRequestSuccess, fRequestError) {
        oModel.read("/ResSubUnitAvaSet", {
            filters: aFilters,
            success: fRequestSuccess,
            error: fRequestError
        });
    };

    DataManager.onReadTeamOverviewData = function(oModel, aFilters, fRequestSuccess, fRequestError) {
        oModel.read("/ResCWAvaSet", {
            filters: aFilters,
            success: fRequestSuccess,
            error: fRequestError
        });
    };

    DataManager.onReadRoleData = function(oModel, aFilters, fRequestSuccess, fRequestError) {
        oModel.read("/ResRoleCapaSet", {
            filters: aFilters,
            success: fRequestSuccess,
            error: fRequestError
        });
    };

    DataManager.onReadServiceData = function(oModel, aFilters, fRequestSuccess, fRequestError) {
        oModel.read("/ResServiceSet", {
            filters: aFilters,
            success: fRequestSuccess,
            error: fRequestError
        });
    };

    DataManager.onReadQualificationData = function(oModel, aFilters, fRequestSuccess, fRequestError) {
        oModel.read("/ResQualSet", {
            filters: aFilters,
            success: fRequestSuccess,
            error: fRequestError
        });
    };

    DataManager.onReadNonProdData = function(oModel, aFilters, fRequestSuccess, fRequestError) {
        oModel.read("/ResNonProdTalSet", {
            filters: aFilters,
            success: fRequestSuccess,
            error: fRequestError
        });
    };

    DataManager.onReadActivityData = function(oModel, aFilters, fRequestSuccess, fRequestError) {
        oModel.read("/ResActivityCapaSet", {
            filters: aFilters,
            success: fRequestSuccess,
            error: fRequestError
        });
    };

    DataManager.onReadResourceOriginData = function(oModel, aFilters, fRequestSuccess, fRequestError) {
        oModel.read("/ResOrigionSet", {
            filters: aFilters,
            success: fRequestSuccess,
            error: fRequestError
        });
    };

    DataManager.onReadQualViewData = function(oModel, aFilters, fRequestSuccess, fRequestError) {
        oModel.read("/ResQualAvaSet", {
            filters: aFilters,
            success: fRequestSuccess,
            error: fRequestError
        });
    };

    DataManager.onErrorResponse = function(oResponse) {
        var sMessage = i18n.getText("MASTER_VIEW_WARNING_MSG") + "\n\ ";
            sMessage += i18n.getText("MASTER_VIEW_WARNING_TICKETINFO");
        var oMessage = sap.m.MessageBox.warning(sMessage, {
                title: i18n.getText("MASTER_VIEW_WARNING_HEADER"),
                styleClass: "",
                initialFocus: null,
                textDirection: sap.ui.core.TextDirection.Inherit
            });
        return oMessage;
    };

    return DataManager;

});
