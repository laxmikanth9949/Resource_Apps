sap.ui.define([
    "sap/ui/core/util/MockServer",
    "sap/ui/model/odata/v2/ODataModel",
    "sap/coe/capacity/analysis/view/Master.controller",
    "sap/coe/capacity/reuselib/controls/QualificationSelectTest/QualificationSelectComponent",
    "sap/ui/thirdparty/sinon"
], function(MockServer) {
    "use strict";
    return {
        init: function() {
            // create
            /* eslint-disable sap-no-hardcoded-url */
            var sPrefix = "https://",
            sUri = sPrefix + "pgtmain.wdf.sap.corp/sap/opu/odata/sap/ZS_AGS_DASHBOARDS_SRV/";
            /* eslint-enable sap-no-hardcoded-url */

            var oMockServer = new MockServer({
                rootUri: sUri
            });
            var oUriParameters = jQuery.sap.getUriParameters();
            // configure
            MockServer.config({
                autoRespond: true,
                autoRespondAfter: oUriParameters.get("serverDelay") || 1000
            });
            // simulate
            var sPath = jQuery.sap.getModulePath("sap.coe.capacity.analysis.localService");
            oMockServer.simulate(sPath + "/metadata.xml", {
                sMockdataBaseUrl: sPath + "/mockdata",
                aEntitySetsNames: ["OrgUnitSet", "SubOrgUnitSet", "QualificationList", "ResActivityCapaSet", "ResQualAvaSet",
                    "ResCapacityHSet", "ResCWAvaSet", "ResNonProdTalSet", "ResOrigionSet", "ResQualSet", "ResRoleCapaSet",
                    "ResSchedObjectSet", "ResServCapacitySet", "ResSubUnitAvaSet", "ResQualificationSet",
                    "ResTimeSpecSet", "ResServiceSet", "ResServiceTeamSet", "SearchVariants", "VariantDetails"
                ]
            });

            this._mockTime();
            this._mockOrganisationUnitRequest();

            // start
            oMockServer.start();
        },

        _mockTime: function() {
            sap.coe.capacity.analysis.view.Master.prototype._initCWOriginal = sap.coe.capacity.analysis.view.Master.prototype._initCWSlider;
            sap.coe.capacity.analysis.view.Master.prototype._initCWSlider = function() {
                var clock = sinon.useFakeTimers(new Date(2016, 6, 15).getTime()); //Mock all the calls to Date() returning 15/07/2016 in _initCWSlider method
                var returnValue = this._initCWOriginal.apply(this, arguments);
                clock.restore();
                return returnValue;
            };

            sap.coe.capacity.reuselib.controls.QualificationSelectTest.QualificationSelectComponent.prototype._createFiltersOriginal = sap.coe.capacity.reuselib.controls.QualificationSelectTest.QualificationSelectComponent.prototype._createFilters;
            sap.coe.capacity.reuselib.controls.QualificationSelectTest.QualificationSelectComponent.prototype._createFilters = function() {
                var clock = sinon.useFakeTimers(new Date(2016, 6, 15).getTime()); //Mock all the calls to Date() returning 15/07/2016 in _createFilters method
                var returnValue = this._createFiltersOriginal.apply(this, arguments);
                clock.restore();
                // Need to overwrite sPath as backend implementation is unusual
                returnValue[2].sPath = "QKID";
                return [returnValue[2]];
            };
        },

        _mockOrganisationUnitRequest: function() {
            sap.ui.model.odata.v2.ODataModel.prototype._readOriginal = sap.ui.model.odata.v2.ODataModel.prototype.read;
            sap.ui.model.odata.v2.ODataModel.prototype.read = function() {

                if (arguments[0].indexOf("OrgUnitSet") !== -1) {
                    var sQuery = arguments[0];
                    var sEmpId = sQuery.split("/OrgUnitSet(EmpId='")[1].split("'")[0];
                    var sOrgId = sQuery.split("/OrgUnitSet(EmpId='")[1].split("',OrgId='")[1].split("'")[0];

                    if (sEmpId === "") {
                        sEmpId = "I327678";
                    }

                    if (sOrgId === "") {
                        sOrgId = "30015950";
                    }

                    arguments[0] = "/OrgUnitSet(EmpId='" + sEmpId + "',OrgId='" + sOrgId + "')";


                    var successOriginal = arguments[1].success;

                    arguments[1].success = function(odata, response) {
                        var odata2 = odata.results[0];
                        successOriginal(odata2, response);
                    };
                }

                return this._readOriginal.apply(this, arguments);
            };
        }
    };
});
