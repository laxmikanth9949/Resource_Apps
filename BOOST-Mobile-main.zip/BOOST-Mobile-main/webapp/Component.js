sap.ui.getCore().loadLibrary("sapit", { url: sap.ui.require.toUrl("sap/support/boostm") + "/resources/sapit", async:true });
sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/model/json/JSONModel",
	"sap/support/boostm/model/models",
	"sapit/util/cFLPAdapter" 
], function(UIComponent, JSONModel, models,cFLPAdapter) {
	"use strict";

	return UIComponent.extend("sap.support.boostm.Component", {

		metadata: {
			manifest: "json"
		},
		"config": {
			"fullWidth": true,
			"reportingId": "db9f4f27-9ffd-4792-b0b3-39c0bf83943d"
		},
		
		init: function() {
			
			// call the base component's init function
		    cFLPAdapter.init(); 
			UIComponent.prototype.init.apply(this, arguments);

			// set the device model
			this.setModel(models.createDeviceModel(), "device");

			this.getModel().setUseBatch(false);

			//Router Initialization
			this.getRouter().initialize();
				/* Mobile Usage Reporting */
			/* Version v3 */
			sap.git = sap.git || {}, sap.git.usage = sap.git.usage || {}, sap.git.usage.Reporting = {
				_lp: null,
				_load: function (a) {
					this._lp = this._lp || sap.ui.getCore().loadLibrary("sap.git.usage", {
						url: "https://trackingshallwe.hana.ondemand.com/web-client/v3",
						async: !0
					}), this._lp.then(function () {
						a(sap.git.usage.MobileUsageReporting)
					}, this._loadFailed)
				},
				_loadFailed: function (a) {
					jQuery.sap.log.warning("[sap.git.usage.MobileUsageReporting]", "Loading failed: " + a)
				},
				setup: function (a) {
					this._load(function (b) {
						b.setup(a)
					})
				},
				addEvent: function (a, b) {
					this._load(function (c) {
						c.addEvent(a, b)
					})
				},
				setUser: function (a, b) {
					this._load(function (c) {
						c.setUser(a, b)
					})
				}
			};

			sap.git.usage.Reporting.setup(this);
		}
	});
});